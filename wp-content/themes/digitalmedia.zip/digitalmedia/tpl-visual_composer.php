
<?php /* Template Name: VC Page */
	get_header() ;
	$meta = _WSH()->get_meta('_bunch_header_settings');
	$bg = digitalmedia_set($meta, 'header_img');
	$title = digitalmedia_set($meta, 'header_title');
?>
<?php if(digitalmedia_set($meta, 'breadcrumb')):?>
<section class="inner-banner" <?php if($bg):?>style="background-image:url('<?php echo esc_attr($bg)?>');"<?php endif;?>>
	<div class="auto-container clearfix">
		<div class="title pull-left">
			<h3><?php if($title) echo wp_kses_post($title); else wp_title('');?></h3>
		</div><!-- /.title pull-left -->
		<div class="breadcumb pull-right">
			<ul class="list-inline">
				<?php echo wp_kses_post(digitalmedia_get_the_breadcrumb()); ?>
			</ul><!-- /.list-inline -->
		</div><!-- /.breadcumb pull-right -->
	</div><!-- /.auto-container -->
</section>
<?php endif;?>
<?php while( have_posts() ): the_post(); ?>
<?php the_content(); ?>
<?php endwhile;  ?>
<?php get_footer() ; ?>