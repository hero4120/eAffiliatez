<?php $options = _WSH()->option();
	Global $wp_query;
	$icon_href = (digitalmedia_set( $options, 'site_favicon' )) ? digitalmedia_set( $options, 'site_favicon' ) : get_template_directory_uri().'/images/favicon.png';
 ?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
	<head>
		 <!-- Basic -->
	    <meta charset="<?php bloginfo( 'charset' ); ?>">
	    <meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
		<!-- Favcon -->
		<?php if ( ! function_exists( 'has_site_icon' ) || ! has_site_icon() ):?>
			<link rel="shortcut icon" type="image/png" href="<?php echo esc_url($icon_href);?>">
		<?php endif;?>
		<?php wp_head(); ?>
	</head>
	<body <?php body_class(); ?>>
	
    <div class="page-wrapper">
 	<?php if(digitalmedia_set($options, 'preloader')):?>
    <!-- Preloader -->
    <div class="preloader"></div>
 	<?php endif;?>
    <!-- Main Header -->
	<?php if(!(digitalmedia_set($options, 'hide_top_bar'))):?>
   <section id="top-bar">
	<div class="auto-container clearfix">
		<?php if(!(digitalmedia_set($options, 'hide_top_text'))):?>
		<div class="left-info pull-left">
			<p><?php echo wp_kses_post(digitalmedia_set($options, 'welcome'));?></p>
		</div>
		<?php endif;?>
		<?php if(!(digitalmedia_set($options, 'hide_social_top'))):?>
			<?php if($socials = digitalmedia_set(digitalmedia_set($options, 'social_media'), 'social_media')):?> 	
				 <div class="social-icon pull-right">
	               <?php foreach($socials as $key => $value):
			if(digitalmedia_set($value, 'tocopy')) continue;?>    
							<a href="<?php echo esc_url(digitalmedia_set($value, 'social_link'));?>"><i class="fa <?php echo digitalmedia_set($value, 'social_icon');?>" aria-hidden="true"></i></a>
				<?php endforeach;?>				
	             </div>
			<?php endif;?>
			<?php endif;?>
	</div>
</section>
<?php endif;?>

<header class="header clearfix">

    <div class="main-header stricky">
        <div class="container">
            <div class="logo pull-left">
                <?php if(digitalmedia_set($options, 'logo_image')):?>
					<a href="<?php echo esc_url( home_url( '/' ) ); ?>"><img src="<?php echo esc_url(digitalmedia_set($options, 'logo_image'));?>" alt="" title="<?php esc_html_e('digitalmedia', 'digitalmedia');?>"></a>
					<?php else:?>
						<a href="<?php echo esc_url( home_url( '/' ) ); ?>"><img src="<?php echo esc_url(get_template_directory_uri().'/images/logo.png');?>" alt="<?php esc_html_e('digitalmedia', 'digitalmedia');?>"></a>
					<?php endif;?>
            </div>

            <div class="nav-outer">
                <nav class="mainmenu-area">
                    <div class="navbar" role="navigation">
                        <div class="navbar-header">
                            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                                <span class="sr-only"><?php esc_html_e('Toggle navigation', 'digitalmedia');?></span>
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                            </button>
                            
                        </div>

                        <div class="navbar-collapse collapse text-center">  
                            <ul>
							<?php wp_nav_menu( array( 'theme_location' => 'main_menu', 'container_id' => 'navbar-collapse-1',
											'container_class'=>'navbar-collapse collapse navbar-right',
											'menu_class'=>'nav navbar-nav',
											'fallback_cb'=>false, 
											'items_wrap' => '%3$s', 
											'container'=>false,
											'walker'=> new Bunch_Bootstrap_walker()  
								) ); ?>

                            </ul> 
                        </div> 
                    </div>
                </nav>

                
            </div>

        </div>
    </div>
</header>
