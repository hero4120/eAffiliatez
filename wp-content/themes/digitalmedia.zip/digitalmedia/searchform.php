<div class="single-sidebar">
	<div class="search-box">
		<form action="#" class="clearfix">
		<form  class="clearfix" action="<?php echo esc_url(home_url('/')); ?>" method="get">
			<input type="search" name="s" value="" placeholder="<?php esc_html_e('Search', 'digitalmedia');?>">
			<button type="submit"><i class="fa fa-search"></i></button>
		</form>
	</div><!-- /.search-box -->
</div><!-- /.single-sidebar -->

